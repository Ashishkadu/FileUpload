import React, { Component} from 'react'
import axios from 'axios';
import {Navigate } from 'react-router-dom';
import Home from './Home';
export default class Login extends Component {


  
  state = {
    username: null,
    password: null,
    usernameValid: false,
    passwordValid: false,
    loginn: false
  }

  doLogin = () =>{
    const email = this.state.username;
    const password = this.state.password;
    
  axios({
    method:'post',
    url:'/login',
    data:{
      userName: email,
      userPassword:password
    }
  })
  .then((response) =>{
    console.log(response);
  });
  }

  render() {
    return (
      <form>
        <h3>Sign In</h3>
        <div className="mb-3">
          <label>Username</label>
          <input
            type="text"
            className="form-control"
            placeholder="Enter username"
            value={this.state.username}
            onChange={(e) => this.setState({ username: e.target.value, usernameValid: true })}
          />
        </div>
        <div className="mb-3">
          <label>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter password"
            value={this.state.password}
            onChange={(e) => this.setState({ password: e.target.value, passwordValid: true })}
          />
        </div>
        <div className="d-grid">
          <button
          disabled = {!this.state.usernameValid || !this.state.passwordValid}
          onClick={this.doLogin}
            type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>

      </form>
    )
  }
}