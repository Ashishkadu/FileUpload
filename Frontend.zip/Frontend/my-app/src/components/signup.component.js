import React, { Component } from 'react'
import axios from 'axios';
export default class SignUp extends Component {
    state = {
      username: null,
      password: null,
      usernameValid: false,
      passwordValid: false,
    
    }


    doRegister = () =>{
      const email = this.state.username;
    const password = this.state.password;

  axios({
    method:'post',
    url:'/register',
    data:{
      userName: email,
      userPassword:password
    }
  });
}
  

render(){
    return (
      <form>
      <h3>Sign Up</h3>
      <div className="mb-3">
        <label>Username</label>
        <input
          type="text"
          className="form-control"
          placeholder="Enter username"
          value={this.state.username}
          onChange={(e) => this.setState({ username: e.target.value, usernameValid: true })}
        />
      </div>
      <div className="mb-3">
        <label>Password</label>
        <input
          type="password"
          className="form-control"
          placeholder="Enter password"
          value={this.state.password}
          onChange={(e) => this.setState({ password: e.target.value, passwordValid: true })}
        />
      </div>
      <div className="d-grid">
        <button
        disabled = {!this.state.usernameValid || !this.state.passwordValid}
         onClick={this.doRegister} type="submit" className="btn btn-primary">
          Submit
        </button>
      </div>
      <p className="forgot-password text-right">
          Already registered <a href="/sign-in">sign in?</a>
        </p>
    </form>
    )
  }
}

